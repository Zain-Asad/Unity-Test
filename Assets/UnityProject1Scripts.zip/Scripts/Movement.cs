using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public Rigidbody rb;
    private void Start()
    {
        rb.freezeRotation = true;
    }

    // Update is called once per frame
    private void FixedUpdate()
    {
        rb.AddForce(0,0, 2000 * Time.deltaTime);
    }
}
